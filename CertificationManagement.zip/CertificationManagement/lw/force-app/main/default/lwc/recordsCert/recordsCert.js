    import { LightningElement, wire, track } from 'lwc';
import getcertData from '@salesforce/apex/getData.getcertData';
import { updateRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import ID_FIELD from '@salesforce/schema/Certification__c.Cert_Id__c';
import CERTIFICATION_OBJECT from '@salesforce/schema/Certification__c';
import CERTNAME2_FIELD from '@salesforce/schema/Certification__c.Name';
import COMMENTS2_FIELD from '@salesforce/schema/Certification__c.Comments__c';
import deleteCertificationList from '@salesforce/apex/getData.deleteCertificationList';

const columns = [
    {label: 'Certification Id', fieldName:'Cert_Id__c'},
    {label: 'Certification Name', fieldName:'Name', editable: true},
    {label: 'Comments', fieldName:'Comments__c', editable: true}
];

export default class CertificationList extends LightningElement {
    @track error;
    @track data;
    @track columns = columns;
    @track draftValues = [];
    @track recordsCount =0;
    @track buttonLabel = 'Delete';
    @track isTrue = false;


    selectedRecords = [];
    refreshTableResult;
    error;
    
    

    certificationObject = CERTIFICATION_OBJECT;
    myFields = [ID_FIELD , CERTNAME2_FIELD , COMMENTS2_FIELD];

    @wire(getcertData) certification;
    refreshTable(result) {
        this.refreshTableResult = result;
        if (result.data) {
            this.data = result.data;
            this.error = undefined;

        } else if (result.error) {
            this.error = result.error;
            this.data = undefined;
        }
    }

    getSelectedRecords(event) {
        const selectedRows = event.detail.selectedRows;
        this.recordsCount = event.detail.selectedRows.length;
        let certIds = new Set();

        for(let i =0;i<selectedRows.length;i++){
            certIds.add(selectedRows[i].Id);
        }

        this.selectedRecords = Array.from(certIds);
    }
    deleteCertifications(){
        if(this.selectedRecords) {
            this.buttonLabel = 'Processing...';
            this.isTrue = true;
            this.deleteCerts();
        }
    }

    deleteCerts(){
        deleteCertificationList({lstCertIds: this.selectedRecords})
        .then(result => {
            this.buttonLabel = 'Delete';
            this.isTrue = false;
                this.dispatchEvent(
                    new ShowToastEvent({
                    title:'Successfully deleted!',
                    message: this.recordsCount + ' Certifications are deleted.',
                    variant: 'success'
                }),
            );
            this.template.querySelector('lightning-datatable').selectedRows = [];
            this.recordsCount = 0;
            //location.reload(true);
            this.dispatchEvent(new CustomEvent('recordChange'));
            return refreshApex(this.certification);
            
        })
        .catch(error => {
            window.console.log(error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error while getting Contacts', 
                    message: error.message, 
                    variant: 'error'
                }),
            );
        });
    }

    handleSave(event) {
        const recordInputs =  event.detail.draftValues.slice().map(draft => {
            const fields = Object.assign({}, draft);
            return { fields };
        });
    
        const promises = recordInputs.map(recordInput => updateRecord(recordInput));
        Promise.all(promises).then(contacts => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Contacts updated',
                    variant: 'success'
                })
            );
             // Clear all draft values
             this.draftValues = [];
             //location.reload(true);
             this.dispatchEvent(new CustomEvent('recordChange'));
             // Display fresh data in the datatable
             return refreshApex(this.certification);
        }).catch(error => {
            // Handle error
        });
    }
}