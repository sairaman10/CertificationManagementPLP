
import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { createRecord, updateRecord, deleteRecord } from 'lightning/uiRecordApi';
 
import getvouData from '@salesforce/apex/getData.getvouData';
import { refreshApex } from '@salesforce/apex';
import VOUCHER_Object from '@salesforce/schema/Voucher__c';
import NAME_FIELD from '@salesforce/schema/Voucher__c.Name';
import ID_FIELD from '@salesforce/schema/Voucher__c.Voucher_Id__c';
import COST_FIELD from '@salesforce/schema/Voucher__c.Voucher_Cost__c';
import VALIDITY_FIELD from '@salesforce/schema/Voucher__c.Validity__c';
import CERTIFICATION_FIELD from '@salesforce/schema/Voucher__c.Certification__c';
import ACTIVE_FIELD from '@salesforce/schema/Voucher__c.Active__c';
import COMMENTS_FIELD from '@salesforce/schema/Voucher__c.Comments__c';
 

 
export default class Voucherform extends LightningElement {
    VoucherId;
     addVoucher(event) {
        const fields = {};
        fields[NAME_FIELD.fieldApiName] = event.detail.fields.Name;
        fields[ID_FIELD.fieldApiName] = event.detail.fields.Voucher_Id__c;
        fields[COST_FIELD.fieldApiName] = event.detail.fields.Voucher_Cost__c;
        fields[VALIDITY_FIELD.fieldApiName] = event.detail.fields.Validity__c;
        fields[CERTIFICATION_FIELD.fieldApiName] = event.detail.fields.Certification__c;
        fields[ACTIVE_FIELD.fieldApiName] = event.detail.fields.Active__c;
        fields[COMMENTS_FIELD.fieldApiName] = event.detail.fields.Comments__c;
        console.log(fields)
        const recordInput = {apiName: VOUCHER_Object.objectApiName, fields };
        createRecord(recordInput)
            .then(Voucher__c => {
                this.VoucherId=Voucher__c.Id;
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Account created',
                        variant: 'success',
                    }),
                );
                this.dispatchEvent(new CustomEvent('recordChange'));
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error',
                    }),
                );
            });
    }
}
