import { LightningElement, wire, track } from 'lwc';
import getvouData from '@salesforce/apex/getData.getvouData';
import { updateRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
 
import ID_FIELD from '@salesforce/schema/Voucher__c.Voucher_ID__c';
import VOUCHER_OBJECT from '@salesforce/schema/Voucher__c';
import VOUCHERNAME_FIELD from '@salesforce/schema/Voucher__c.Name';
import CERTIFICATION_FIELD from '@salesforce/schema/Voucher__c.Certification__r.Name';
import VOUCHERCOST_FIELD from '@salesforce/schema/Voucher__c.Voucher_Cost__c';
import ACTIVE_FIELD from '@salesforce/schema/Voucher__c.Active__c';
import VALIDITY_FIELD from '@salesforce/schema/Voucher__c.Validity__c';
import COMMENTS_FIELD from '@salesforce/schema/Voucher__c.Comments__c';
import deleteVoucherList from '@salesforce/apex/getData.deleteVoucherList';
 
const columns = [
    { label:'Id', fieldName:'Voucher_Id__c'},
    { label:'Voucher Name',fieldName:'Name',editable:true},
    { label:'Certification', fieldName:'Certification__c'},
    { label:'Voucher Cost', fieldName:'Voucher_Cost__c',type:'currency', editable:true},
    { label:'Active', fieldName:'Active__c', type:'boolean'},
    { label:'Validity', fieldName:'Validity__c', type:'date', editable:true},
    { label:'Comments', fieldName:'Comments__c', editable:true }

];
 
export default class RecordsVoucher extends LightningElement {
    @track error;
    @track data;
    @track columns = columns;
    @track draftValues = [];
    @track recordsCount =0;
    @track buttonLabel = 'Delete';
    @track isTrue = false;
 
 
    selectedRecords = [];
    refreshTableResult;
    error;
    
    
 
    voucherObject = VOUCHER_OBJECT;
    myFields = [ID_FIELD , VOUCHERNAME_FIELD ,CERTIFICATION_FIELD ,VOUCHERCOST_FIELD,
        ACTIVE_FIELD,VALIDITY_FIELD,COMMENTS_FIELD];
 
    @wire(getvouData) Voucher;
    refreshTable(result) {
        this.refreshTableResult = result;
        if (result.data) { 
            let values=[];
            result.data.forEach(i => {
                let value={};
                value.Id=i.Id;
                value.Voucher_Id__c=i.Voucher_Id__c;
                value.Name=i.Name;
                value.Certification__c=i.Certification__r.Name;
                value.Voucher_Cost__c =i.Voucher_Cost__c;
                value.Active__c=i.Active__c;
                value.Validity__c=i.Validity__c;
                value.Comments__c=i.Comments__c;
                values.push(value);
            });
            this.data=values;

            
            this.error = undefined;
 
        } else if (result.error) {
            this.error = result.error;
            this.data = undefined;
        }
    }
 
    getSelectedRecords(event) {
        const selectedRows = event.detail.selectedRows;
        this.recordsCount = event.detail.selectedRows.length;
        let vouIds = new Set();
 
        for(let i =0;i<selectedRows.length;i++){
            vouIds.add(selectedRows[i].Id);
        }
 
        this.selectedRecords = Array.from(vouIds);
    }
    deleteVoucher(){
        if(this.selectedRecords) {
            this.buttonLabel = 'Processing...';
            this.isTrue = true;
            this.deleteVou();
        }
    }
 
    deleteVou(){
        deleteVoucherList({lstVouIds: this.selectedRecords})
        .then(result => {
            this.buttonLabel = 'Delete';
            this.isTrue = false;
                this.dispatchEvent(
                    new ShowToastEvent({
                    title:'Successfully deleted!',
                    message: this.recordsCount + ' Vouchers are deleted.',
                    variant: 'success'
                }),
            );
            this.template.querySelector('lightning-datatable').selectedRows = [];
            this.recordsCount = 0;
        
            this.dispatchEvent(new CustomEvent('recordChange'));
            return refreshApex(this.Voucher);
            
        })
        .catch(error => {
            window.console.log(error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error while getting Contacts', 
                    message: error.message, 
                    variant: 'error'
                }),
            );
        });
    }
 
    handleSave(event) {
        const recordInputs =  event.detail.draftValues.slice().map(draft => {
            const fields = Object.assign({}, draft);
            return { fields };
        });
    
        const promises = recordInputs.map(recordInput => updateRecord(recordInput));
        Promise.all(promises).then(contacts => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Voucher updated',
                    variant: 'success'
                })
            );
             
             this.draftValues = [];
            
             this.dispatchEvent(new CustomEvent('recordChange'));
             
             return refreshApex(this.Voucher);
        }).catch(error => {
            
        });
    }
}
