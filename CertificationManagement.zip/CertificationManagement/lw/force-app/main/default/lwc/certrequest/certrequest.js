
import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


 
export default class Certrequest extends LightningElement {
    
    showNotification(){
        const evt = new ShowToastEvent({
            title:'Success',
            message: 'Record is created',
            varient:'Success',
        });
        this.dispatchEvent(new CustomEvent('recordChange'));
    }
}
