import { LightningElement,wire,track,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
import { createRecord, updateRecord, deleteRecord } from 'lightning/uiRecordApi';
 
import getcertData from '@salesforce/apex/getData.getcertData';
import Certification_Object from '@salesforce/schema/Certification__c';
import CertID_FIELD from '@salesforce/schema/Certification__c.Cert_Id__c';
import CertNAME_FIELD from '@salesforce/schema/Certification__c.Name';
import CertCOMMENTS_FIELD from '@salesforce/schema/Certification__c.Comments__c';
 

 
export default class CertificationDetails extends LightningElement {
 @api recordId;
    //inserting data into database
Name='';
Id='';
Comments='';
 
    inputChange(event){
        if( event.target.name == 'Name' ){
            this.Name = event.target.value;
        }
        else if( event.target.name == 'Id' ){
            this.Id = event.target.value;
        }
       
        else if( event.target.name == 'Comments' ){
            this.Comments = event.target.value;
        }
     }
     addCertificate() {
        const fields = {};
        fields[CertNAME_FIELD.fieldApiName] = this.Name;
        fields[CertID_FIELD.fieldApiName] = this.Id;
        fields[CertCOMMENTS_FIELD.fieldApiName] = this.Comments;
        const recordInput = { apiName: Certification_Object.objectApiName, fields };
        createRecord(recordInput)
            .then(() => {
                
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Account created',
                        variant: 'success',
                    }),
                );
                this.dispatchEvent(new CustomEvent('recordChange'));
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error',
                    }),
                );
            });
    }
}