import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { createRecord, updateRecord, deleteRecord } from 'lightning/uiRecordApi';
 
import getEmployeeList from '@salesforce/apex/getData.getEmployeeList';
import { refreshApex } from '@salesforce/apex';
import Employee_Object from '@salesforce/schema/Employee__c';
import ID_FIELD from '@salesforce/schema/Employee__c.Emp_ID__c';
import NAME_FIELD from '@salesforce/schema/Employee__c.Name';
import EMAIL_FIELD from '@salesforce/schema/Employee__c.Mail__c';
import PRIMARY_FIELD from '@salesforce/schema/Employee__c.Primary_Skill__c';
import SECONDARY_FIELD from '@salesforce/schema/Employee__c.Secondary_Skill__c';
import EXPERIENCE_FIELD from '@salesforce/schema/Employee__c.Experience__c';
import COMMENTS_FIELD from '@salesforce/schema/Employee__c.Comments__c';
 

 
 
export default class Employeedeets extends LightningElement {
    
Name='';
Id='';
Email='';
PrimarySkill='';
SecondarySkill='';
Experience='';
Comments='';
 
    inputChange(event){
        if( event.target.name == 'Name' ){
            this.Name = event.target.value;
        }
        else if( event.target.name == 'Id' ){
            this.Id = event.target.value;
        }
        else if( event.target.name == 'Email' ){
            this.Email = event.target.value;
        }
        else if( event.target.name == 'PrimarySkill' ){
            this.PrimarySkill = event.target.value;
        }
        
        else if( event.target.name == 'SecondarySkill' ){
            this.SecondarySkill = event.target.value;
        }
        
        else if( event.target.name == 'Experience' ){
            this.Experience = event.target.value;
        }
        else if( event.target.name == 'Comments' ){
            this.Comments = event.target.value;
        }
     }
     addEmployee() {
        const fields = {};
        fields[NAME_FIELD.fieldApiName] = this.Name;
        fields[ID_FIELD.fieldApiName] = this.Id;
        fields[EMAIL_FIELD.fieldApiName] = this.Email;
        fields[PRIMARY_FIELD.fieldApiName] = this.PrimarySkill;
        fields[SECONDARY_FIELD.fieldApiName] = this.SecondarySkill;
        fields[EXPERIENCE_FIELD.fieldApiName] = this.Experience;
        fields[COMMENTS_FIELD.fieldApiName] = this.Comments;
        const recordInput = { apiName: Employee_Object.objectApiName, fields };
        createRecord(recordInput)
            .then(() => {
                
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Account created',
                        variant: 'success',
                    }),
                );
                this.dispatchEvent(new CustomEvent('recordChange'));
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error creating record',
                        message: error.body.message,
                        variant: 'error',
                    }),
                );
            });
    }
 

}