import { LightningElement, wire, track } from 'lwc';
import getEmployeeList from '@salesforce/apex/getData.getEmployeeList';
import { updateRecord } from 'lightning/uiRecordApi';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
 
import ID_FIELD from '@salesforce/schema/Employee__c.Emp_ID__c';
import EMPLOYEE_OBJECT from '@salesforce/schema/Employee__c';
import EMPNAME_FIELD from '@salesforce/schema/Employee__c.Name';
import PRIMARYSKILL_FIELD from '@salesforce/schema/Employee__c.Primary_Skill__c';
import SECONDARYSKILL_FIELD from '@salesforce/schema/Employee__c.Secondary_Skill__c';
import EXPERIENCE_FIELD from '@salesforce/schema/Employee__c.Experience__c';
import COMMENTS_FIELD from '@salesforce/schema/Employee__c.Comments__c';
import MAIL_FIELD from '@salesforce/schema/Employee__c.Mail__c';
import deleteEmployeeList from '@salesforce/apex/getData.deleteEmployeeList';
 
const columns = [
    {label: 'EmployeeId', fieldName:'Emp_Id__c'},
    {label: 'Employee Name', fieldName:'Name', editable: true},
    {label: 'Primary Skills', fieldName:'Primary_Skill__c',editable:true},
    {label: 'Secondary Skills', fieldName:'Secondary_Skill__c',editable:true},
    {label: 'Experience', fieldName:'Experience__c', editable: true},
    {label: 'Mail' ,fieldName:'Mail__c',editable:true},
    {label: 'Comments', fieldName:'Comments__c', editable: true}
];
 
export default class RecordsEmp extends LightningElement {
    @track error;
    @track data;
    @track columns = columns;
    @track draftValues = [];
    @track recordsCount =0;
    @track buttonLabel = 'Delete';
    @track isTrue = false;
 
 
    selectedRecords = [];
    refreshTableResult;
    error;
    
    
 
    employeeObject = EMPLOYEE_OBJECT;
    myFields = [ID_FIELD , EMPNAME_FIELD ,PRIMARYSKILL_FIELD,SECONDARYSKILL_FIELD, COMMENTS_FIELD,
        EXPERIENCE_FIELD,MAIL_FIELD];
 
    @wire(getEmployeeList) Employee;
    refreshTable(result) {
        this.refreshTableResult = result;
        if (result.data) {
            this.data = result.data;
            this.error = undefined;
 
        } else if (result.error) {
            this.error = result.error;
            this.data = undefined;
        }
    }
 
    getSelectedRecords(event) {
        const selectedRows = event.detail.selectedRows;
        this.recordsCount = event.detail.selectedRows.length;
        let empIds = new Set();
 
        for(let i =0;i<selectedRows.length;i++){
            empIds.add(selectedRows[i].Id);
        }
 
        this.selectedRecords = Array.from(empIds);
    }
    deleteEmployee(){
        if(this.selectedRecords) {
            this.buttonLabel = 'Processing...';
            this.isTrue = true;
            this.deleteEmp();
        }
    }
 
    deleteEmp(){
        deleteEmployeeList({lstEmpIds: this.selectedRecords})
        .then(result => {
            this.buttonLabel = 'Delete';
            this.isTrue = false;
                this.dispatchEvent(
                    new ShowToastEvent({
                    title:'Successfully deleted!',
                    message: this.recordsCount + ' Certifications are deleted.',
                    variant: 'success'
                }),
            );
            this.template.querySelector('lightning-datatable').selectedRows = [];
            this.recordsCount = 0;
            
            this.dispatchEvent(new CustomEvent('recordChange'));
            return refreshApex(this.Employee);
            
        })
        .catch(error => {
            window.console.log(error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error while getting Employees', 
                    message: error.message, 
                    variant: 'error'
                }),
            );
        });
    }
 
    handleSave(event) {
        const recordInputs =  event.detail.draftValues.slice().map(draft => {
            const fields = Object.assign({}, draft);
            return { fields };
        });
    
        const promises = recordInputs.map(recordInput => updateRecord(recordInput));
        Promise.all(promises).then(contacts => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Contacts updated',
                    variant: 'success'
                })
            );
             
             this.draftValues = [];
             
             this.dispatchEvent(new CustomEvent('recordChange'));
             // Display fresh data in the datatable
             return refreshApex(this.Employee);
        }).catch(error => {
            
        });
    }
}
