declare module "@salesforce/apex/getData.getEmployeeList" {
  export default function getEmployeeList(): Promise<any>;
}
declare module "@salesforce/apex/getData.deleteEmployeeList" {
  export default function deleteEmployeeList(param: {lstEmpIds: any}): Promise<any>;
}
declare module "@salesforce/apex/getData.getcertData" {
  export default function getcertData(): Promise<any>;
}
declare module "@salesforce/apex/getData.deleteCertificationList" {
  export default function deleteCertificationList(param: {lstCertIds: any}): Promise<any>;
}
declare module "@salesforce/apex/getData.getvouData" {
  export default function getvouData(): Promise<any>;
}
declare module "@salesforce/apex/getData.deleteVoucherList" {
  export default function deleteVoucherList(param: {lstVouIds: any}): Promise<any>;
}
declare module "@salesforce/apex/getData.getcertReqData" {
  export default function getcertReqData(): Promise<any>;
}
declare module "@salesforce/apex/getData.deleteCertReqList" {
  export default function deleteCertReqList(param: {lstCertReqIds: any}): Promise<any>;
}
