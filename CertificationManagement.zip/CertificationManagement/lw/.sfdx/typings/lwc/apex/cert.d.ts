declare module "@salesforce/apex/cert.createCertificate" {
  export default function createCertificate(param: {cer: any}): Promise<any>;
}
